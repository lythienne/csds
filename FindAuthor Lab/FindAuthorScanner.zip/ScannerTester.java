import java.io.*;
/**
 * Write a description of class ScannerTester here.
 *
 * @author Anu Datar
 * @version 05/17/2018
 */
public class ScannerTester
{
    /**
     *  Main tester method 
     *
     * @param  str array of String objects 
     */
    public static void main(String[] str) throws FileNotFoundException
    {
        Document doc = new Document("mystery1.txt");
        doc.parseDocument();
        
        for(Sentence s : doc.getSentences())
        {
            System.out.println(s);
        }
    }
}
